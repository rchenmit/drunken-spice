import circuitConstraints
reload(circuitConstraints)
from circuitConstraints import *
from resolveConstraints import *

ra = 100   # 100 ohms
rb = 200   # 200 ohms
rd = 100   # 200 ohms
vc = 10    #  10 volts

# Example 1 in the notes
# Remember that nodes n2 and n4 are really the same.  We'll just use
# the name n2 

ckt = ConstraintSet()
ckt.addConstraint(resistor(ra), ['vn1', 'vn2', 'ia'])
ckt.addConstraint(resistor(rb), ['vn2', 'vn1', 'ib'])
ckt.addConstraint(resistor(rd), ['vn2', 'vn3', 'id'])
ckt.addConstraint(vsrc(vc), ['vn2', 'vn3', 'ic'])

ckt.addConstraint(kcl([-1, 1]), ['ia', 'ib'])  # n1
ckt.addConstraint(kcl([1,-1,-1, -1]), ['ia', 'ib', 'ic', 'id'])  # n2
ckt.addConstraint(setGround, ['vn3'])

solution = resolveConstraints(ckt.getConstraintEvaluationFunction())

ckt.display(solution)

