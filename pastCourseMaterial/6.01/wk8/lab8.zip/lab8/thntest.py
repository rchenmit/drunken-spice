import circuitConstraints
reload(circuitConstraints)
from circuitConstraints import *

import resolveConstraints
reload(resolveConstraints)
from resolveConstraints import *

import genKcl
reload(genKcl)
from genKcl import *

import thevenin
reload(thevenin)
from thevenin import *

import copy

ckt = ConstraintSetKCL()
ckt.addConstraint2T(resistor(20), ['vn1', 'vn3', 'ir'])
ckt.addConstraint2T(resistor(20), ['vn3', 'vn2', 'ir2'])
ckt.addConstraint2T(vsrc(5), ['vn1', 'vn2', 'is'])

# The lines below are just to demonstrate deepcopy
cktcopy = copy.deepcopy(ckt)
cktcopy.addConstraint(setGround, ['vn2'])
cktcopy.genKcls('vn2')
solution = resolveConstraints(cktcopy.getConstraintEvaluationFunction())
cktcopy.display(solution)

# Call to thevenin, should compute vth and rth
thevenin(ckt, 'vn3', 'vn2')


