import circuitConstraints
reload(circuitConstraints)
from circuitConstraints import *

import resolveConstraints
reload(resolveConstraints)
from resolveConstraints import *

ckt = ConstraintSet()
ckt.addConstraint(resistor(20), ['vn1', 'vn2', 'ir'])
ckt.addConstraint(vsrc(5), ['vn1', 'vn2', 'is'])
ckt.addConstraint(kcl([1,1]), ['ir', 'is'])
ckt.addConstraint(setGround, ['vn2'])

solution = resolveConstraints(ckt.getConstraintEvaluationFunction())

ckt.display(solution)



