import circuitConstraints
reload(circuitConstraints)
from circuitConstraints import *

import resolveConstraints
reload(resolveConstraints)
from resolveConstraints import *

import genKcl
reload(genKcl)
from genKcl import *

ckt = ConstraintSetKCL()
ckt.addConstraint2T(resistor(20), ['vn1', 'vn2', 'ir1'])
ckt.addConstraint2T(resistor(10), ['vn2', 'gnd', 'ir2'])
ckt.addConstraint2T(resistor(10), ['vn2', 'gnd', 'ir3'])
ckt.addConstraint2T(vsrc(5), ['vn1', 'gnd', 'is'])
#ckt.addConstraint(kcl([1,1]), ['ir1', 'is'])
#ckt.addConstraint(kcl([-1,1, 1]), ['ir1', 'ir2', 'ir3'])
ckt.genKcls('gnd')

solution = resolveConstraints(ckt.getConstraintEvaluationFunction())
ckt.display(solution)


