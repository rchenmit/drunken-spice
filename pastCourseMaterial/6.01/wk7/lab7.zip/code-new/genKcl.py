import circuitConstraints
reload(circuitConstraints)
from circuitConstraints import *

import resolveConstraints
reload(resolveConstraints)
from resolveConstraints import *

# Defines a derived class which generates the kcl equations for
# Two terminal elements
class ConstraintSetKCL(ConstraintSet):
    def __init__(self):
        pass
        
    def addConstraint2T(self, f, variables):
        pass
        
    def genKcls(self, refNode):
        pass

    def __str__(self):
        pass
