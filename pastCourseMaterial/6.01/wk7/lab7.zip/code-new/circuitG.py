import circuitConstraints
reload(circuitConstraints)
from circuitConstraints import *

import resolveConstraints
reload(resolveConstraints)
from resolveConstraints import *

import genKcl
reload(genKcl)
from genKcl import *

import genGrid
reload(genGrid)
from genGrid import *

ckt = ConstraintSetKCL()

genGridResistors(ckt,10,10,1.0)
genGridVsrcs(ckt,'gnd',10,10,10*[1.0], 10*[2.0], 10*[3.0],10*[4.0])
ckt.addConstraint(setGround, ['gnd'])
ckt.genKcls('gnd')

solution = resolveConstraints(ckt.getConstraintEvaluationFunction())
ckt.display(solution)
