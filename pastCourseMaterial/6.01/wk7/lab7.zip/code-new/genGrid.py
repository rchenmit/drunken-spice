import circuitConstraints
reload(circuitConstraints)
from circuitConstraints import *

import resolveConstraints
reload(resolveConstraints)
from resolveConstraints import *

import genKcl
from genKcl import *

# Generates a grid of resistors with resistors hanging off beginning
# and end of each row, and beginning and end of each column. Left side
# nodes are n0_1, n0_2... n0_nRows, Rightside nodes are nnCols+1_1,
# nnCols+1_2, ... nnCols+1_nRows. Top nodes are n1_0,n2_0,...nnCols_0,
# Bottom nodes are n1_nRows+1, n2_nRows+1, ...nnCols_nRows+1
def genGridResistors(ckt,nRows,nCols,R):
    # Create Columns of resistors
    for i in range(1,nCols+1):
        for j in range(0,nRows+1):
            n1 = 'v%d_%d' % (j,i)
            n2 = 'v%d_%d' % (j+1,i)
            crnt = 'i%d_%d->%d_%d' % (j,i,j+1,i)
            ckt.addConstraint2T(resistor(R), [n1,n2,crnt])

    # Create rows of resistors
    for i in range(nCols+1):
        for j in range(1,nRows+1):
            n1 = 'v%d_%d' % (j,i)
            n2 = 'v%d_%d' % (j,i+1)
            crnt = 'i%d_%d->%d_%d' % (j,i,j,i+1)            
            ckt.addConstraint2T(resistor(R), [n1,n2,crnt])

# Put Voltage sources on periphery of the grid
def genGridVsrcs(ckt,ground,nRows,nCols,vValsL,vValsR,vValsT,vValsB):
    #Put in Left and Right voltage sources
    for j in range(1,nRows+1):
        n1 = 'v%d_%d' % (j,0)
        crnt = 'isrcL%d' % j
        ckt.addConstraint2T(vsrc(vValsL[j-1]), [n1,ground,crnt])
        n1 = 'v%d_%d' % (j,nCols+1)
        crnt = 'isrcR%d' % j
        ckt.addConstraint2T(vsrc(vValsR[j-1]), [n1,ground,crnt])
    #Put in Top and Bottom voltage sources
    for j in range(1,nCols+1):
        n1 = 'v%d_%d' % (0,j)
        crnt = 'isrcT%d' % j
        ckt.addConstraint2T(vsrc(vValsT[j-1]), [n1,ground,crnt])
        n1 = 'v%d_%d' % (nRows+1,j)
        crnt = 'isrcB%d' % j
        ckt.addConstraint2T(vsrc(vValsB[j-1]), [n1,ground,crnt])        

            
    
