# Constraints associated with a circuit

def resistor(R):
    # assumes a list or tuple x = [vn1, vn2, iR]
    return lambda x : x[0] - x[1] - float(R)*x[2]

def vsrc(Vs):
    # assumes a list or tuple x = [vn1, vn2, iSrc]
    return lambda x : x[0] - x[1] - Vs

def kcl(signs):
    # Set up a sum of signed currents = 0 equation
    def kclsum(x):
        return sum([si*xi for (si,xi) in zip(signs,x)])
    return kclsum

def setGround(x):
    # Enforces a constaint that variable should be zero.
    return x[0]

def wire():
    # assumes a list or tuple x = [vn1, vn2, iWire]
    return lambda x : x[0] - x[1]
